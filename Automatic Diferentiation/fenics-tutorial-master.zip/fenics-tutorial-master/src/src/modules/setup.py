from distutils.core import setup
name = 'BoxField'
setup(name=name,
      version='1.0',
      author='Hans Petter Langtangen <hpl@simula.no>',
      py_modules=[name],
      #scripts=[name + '.py'],
      )
