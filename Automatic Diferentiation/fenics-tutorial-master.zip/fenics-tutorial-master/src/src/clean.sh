#!/bin/sh
rm -rf *.vtu *.pvd *.pdf *.png *.pyc __pycache__ tmp* *~ *.mat Results*
