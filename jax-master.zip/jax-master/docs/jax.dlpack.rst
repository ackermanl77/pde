jax.dlpack module
=================

.. automodule:: jax.dlpack
    :members:
    :show-inheritance: