This directory contains team proposals and design documents for public viewing
and discussion.
