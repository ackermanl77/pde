import unittest
from api_tests import *
from gradient_tests import *
from odeint_tests import *

if __name__ == '__main__':
    unittest.main()
