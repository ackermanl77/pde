# Oryx

Oryx is a library for probabilistic programming and deep learning built on top
of Jax. The approach is to expose a set of function transformations that
compose and integrate with JAX's existing transformations (e.g. `jit`, `grad`,
and `vmap`).

## Documentation and Examples

Coming soon!
