# Copyright Contributors to the Pyro project.
# SPDX-License-Identifier: Apache-2.0

from pyro.contrib.randomvariable.random_variable import RandomVariable

__all__ = [
    "RandomVariable",
]
