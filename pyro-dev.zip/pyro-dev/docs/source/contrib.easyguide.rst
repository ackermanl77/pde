Easy Custom Guides
==================

.. automodule:: pyro.contrib.easyguide

EasyGuide
---------
.. autoclass:: pyro.contrib.easyguide.EasyGuide
    :members:
    :undoc-members:
    :special-members: __call__
    :show-inheritance:
    :member-order: bysource

easy_guide
----------
.. autofunction:: pyro.contrib.easyguide.easy_guide

Group
-----
.. autoclass:: pyro.contrib.easyguide.easyguide.Group
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource
