#!/bin/sh
#rm -f automake_sphinx.py  # not used here, see make.sh
doconce clean
rm -rf ftut*.pdf fenics_tutorial*.pdf automake* papers.bib newcommands.tex
