from __future__ import absolute_import

from .fnn import FNN
from .mfnn import MfNN
from .opnn import OpNN
from .resnet import ResNet
