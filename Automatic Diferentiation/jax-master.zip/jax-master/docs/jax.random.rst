jax.random package
==================

.. automodule:: jax.random
    :members:
    :undoc-members:
