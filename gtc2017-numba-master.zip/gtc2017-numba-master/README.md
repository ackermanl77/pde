# gtc2017-numba
Numba tutorial for GTC 2017 conference
