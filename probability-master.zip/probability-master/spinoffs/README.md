# TFP Spinoffs

This directory contains libraries or tools built and maintained by members of
the TensorFlow Probability team, but packaged independently.
