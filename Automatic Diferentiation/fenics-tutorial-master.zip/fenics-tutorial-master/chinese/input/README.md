This file contains the original version of the Tutorial (2017-06-01)
as well as a modified version used as basis for the Chinese translation.
