#!/bin/sh
rm -rf *~ *.vtu *.pvd dolfin_plot* __pychache__ tmp*
