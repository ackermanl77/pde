#!/bin/sh
# Clean up files that can be regenerated
rm -rf uploads/ templates/ static/ controller.py model.py *.pyc *~ clean.sh