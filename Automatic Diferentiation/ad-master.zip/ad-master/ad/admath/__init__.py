"""
================================================================================
ad: Fast, transparent calculations of first and second-order automatic 
differentiation
================================================================================

Author: Abraham Lee
Copyright: 2013

"""

from .admath import *
