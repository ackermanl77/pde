jax.experimental.vectorize module
=================================

.. automodule:: jax.experimental.vectorize
    :members:
    :show-inheritance:
