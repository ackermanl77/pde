Random Variables
================

.. automodule:: pyro.contrib.randomvariable

Random Variable
---------------
.. autoclass:: pyro.contrib.randomvariable.random_variable.RandomVariable
    :members:
    :undoc-members:
    :show-inheritance:
