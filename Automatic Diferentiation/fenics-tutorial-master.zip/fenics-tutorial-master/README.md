The FEniCS Tutorial
===================

By Hans Petter Langtangen and Anders Logg

This repository contains all source files, published documents, and
example programs for the FEniCS Tutorial.

 * `pub`:     Published versions of all documents (book, online version, programs)
 * `src`:     Sources for all documents (book, online version, programs)
 * `review`:  Referee reports from Springer
 * `chinese`: Chinese version (does not use Doconce)
