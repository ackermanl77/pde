jax.experimental package
========================

.. toctree::
    :maxdepth: 1

    jax.experimental.loops
    jax.experimental.optimizers
    jax.experimental.stax
    jax.experimental.vectorize

.. automodule:: jax.experimental
