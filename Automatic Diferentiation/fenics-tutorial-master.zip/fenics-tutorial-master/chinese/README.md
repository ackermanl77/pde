This directory contains the Chinese edition of the book (volume I).
Note that this version does not use Doconce bus instead manually
translated from the generated LaTeX sources.

To build the book, type `make`.
